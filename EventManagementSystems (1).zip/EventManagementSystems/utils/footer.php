<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>E</strong><span class = "small footerSubtext">vent</span>
                        <strong>A</strong><span class = "small footerSubtext">nd</span>
                        <strong>C</strong><span class = "small footerSubtext">atering</span>
                        
                    </p>

                    
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    Brac Univeristy<br>
                    Badda<br>
                    
                </div>
            </section>
            
        </div>
    </div>
</footer>